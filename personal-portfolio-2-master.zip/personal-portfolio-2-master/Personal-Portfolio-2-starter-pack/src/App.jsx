const App = () => {
  //don't forget to add font link in index.html
  return <h1>Subscribe Zainkeepscode</h1>;
};

export default App;
