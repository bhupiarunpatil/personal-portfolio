# Personal-Portfolio-2-starter-pack
  * https://youtubebinjanportfolio.pages.dev

## Fonts link
  * https://stijndv.com/fonts/Eudoxus-Sans.css

## Slick slider links
  * https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css
  
  * https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css
  
## NodeJS
  * https://nodejs.org/en/download/
  
## Git
  * https://git-scm.com/downloads
 
