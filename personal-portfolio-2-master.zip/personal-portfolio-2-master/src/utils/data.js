import { HiOutlineDesktopComputer } from "react-icons/hi";
import { CiMobile1 } from "react-icons/ci";
import { MdWorkspacesOutline } from "react-icons/md";
export const projectExperience = [
  {
    name: "UI/UX Design",
    projects: 6,
    icon: HiOutlineDesktopComputer,
    bg: "#286F6C",
  },
  {
    name: "AWS Project",
    projects: 6,
    icon: CiMobile1,
    bg: "#EEC048",
  },
  // {
  //   name: "Brand Identity",
  //   projects: 47,
  //   icon: MdWorkspacesOutline,
  //   bg: "#F26440",
  // },
];

export const WhatDoIDo = [
  "I am currently pusuing my bacheor degree at Vidya Vardhini's College of Engineering and Technology",
  "We use process design to create digital products. Besides that also help their business",
];

export const workExp = [
  {
    place: "HKI INFOTECH",
    tenure: "Oct 2022 - Nov 2022",
    role: "Visual Designer",
    detail:
      "Designed and implemented UI componets,built the frontend using HTML and CSS.Handled MSSQL with RDBMS knowledg",
  },
  {
    place: "SPARKS FOUNDATION",
    tenure: "May 2023 - Jun 2023",
    role: "Data Science Intern",
    detail:
      " Completed Task as a Data Science and Business Analytics Intern. Utilized supervised and unsupervised machine learning with Python and Jupyter Notebook",
  },
  {
    place: "Figma UI/UX",
    tenure: "Jan 2023 - Mar 2023",
    role: "UI/UX Designer",
    detail:
      "A visual desginer dsesign for a variety of platoforms like flight booking application,weather forcast application",
  },
];

export const comments = [
  {
    name: "Aaryan Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people2.png",
  },
  {
    name: "Aarti Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people1.png",
  },
  {
    name: "Aarti Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people2.png",
  },
  {
    name: "Aarti Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people1.png",
  },
  {
    name: "Aarti Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people2.png",
  },
  {
    name: "Aaryan Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people1.png",
  },
  {
    name: "Aaryan Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people2.png",
  },
  {
    name: "Aaryan Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people1.png",
  },
  {
    name: "Aaryan Ghosh",
    post: "Creative Manager",
    comment:
      "Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    img: "./people2.png",
  },
];

export const sliderSettings = {
  dots: true,
  infinite: false,
  speed: 1000,
  slidesToShow: 3,
  slidesToScroll: 1,
  initialSlide: 0,
  touchMove: true,
  useCSS: true,

  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true,
      },
    },
    {
      breakpoint: 1000,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
};




// export const workExp = [
//   {
//     place: "HKI INFOTEC",
//     tenure: "Oct 2022 - Nov 2022",
//     role: "Web Developer Intern",
//     detail:
//       "Designed and implemented UI componets,built the frontend using HTML and CSS. Handled MSSQL with RDBMS knowledg",
//   },
//   {
//     place: "New Man Services",
//     tenure: "Aug 2022 - Sep 2022",
//     role: "UI/UX Designer",
//     detail:
//       "A visual desginer dsesign for a variety of platoforms like flight booking application,weather forcast application",
//   {
//     place: "Sparks Foundation",
//     tenure: "Aug 2014 - Sep 2016",
//     role: "Data Science Intern",
//     detail:
//       "A visual desginer dsesign for a variety of platoforms, may include internet and internet sites, games, movies, kioasks and wearbies. In short, they create the concepts",
//   },
// ];